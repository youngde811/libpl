
/*
 * Standard header file for libpl.
 */

#ifndef _LIBPL_H
#define _LIBPL_H 1

#include <ucontext.h>

int activity_create(unsigned long *identifier);

#endif  /* _LIBPL_H */
