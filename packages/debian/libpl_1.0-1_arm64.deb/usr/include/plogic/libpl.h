
/*
 * Standard header file for libpl.
 */

#ifndef _LIBPL_H
#define _LIBPL_H 1

#include <ucontext.h>

int getframep(unsigned long *current, unsigned long *parent);

#endif  /* _LIBPL_H */
