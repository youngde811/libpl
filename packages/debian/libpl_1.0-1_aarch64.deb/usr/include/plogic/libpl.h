
/*
 * Standard header file for libpl.
 */

#ifndef _LIBPL_H
#define _LIBPL_H 1

int get_context(unsigned long *current, unsigned long *parent);

#endif  /* _LIBPL_H */
